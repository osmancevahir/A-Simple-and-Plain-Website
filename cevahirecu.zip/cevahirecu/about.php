<?php
    include "header.php";
?>

<!-- =========== About Detay Sayfası =============== --> 

<div class="container">
<section class="hero-about">
   <div class="heading">
        <h1>Biz:CEVAHİRECU</h1>
   </div>
   <div class="contianer-about">    
        <div class="hero-content">
            <p>
               Lorem ipsum dolor sit, amet consectetur adipisicing elit.
               Culpa quas at ipsum vitae officia, eos expedita id placeat
               exercitationem, dolore blanditiis! Cumque quae illum, quam
               ratione veritatis odit labore quisquam.
            </p>
            <p>
               Lorem ipsum dolor sit, amet consectetur adipisicing elit.
               Culpa quas at ipsum vitae officia, eos expedita id placeat
               exercitationem, dolore blanditiis! Cumque quae illum, quam
               ratione veritatis odit labore quisquam.
            </p>
            <p>
               Lorem ipsum dolor sit, amet consectetur adipisicing elit.
               Culpa quas at ipsum vitae officia, eos expedita id placeat
               exercitationem, dolore blanditiis! Cumque quae illum, quam
               ratione veritatis odit labore quisquam.
            </p>
            <p>
               Lorem ipsum dolor sit, amet consectetur adipisicing elit.
               Culpa quas at ipsum vitae officia, eos expedita id placeat
               exercitationem, dolore blanditiis! Cumque quae illum, quam
               ratione veritatis odit labore quisquam.
            </p>
        </div>
        <div class=hero-image>
            <img src="assets/img/ecu2 (1).jpg" alt="">
        </div>
   </div>

</section>
</div>
<?php 
    include "footer.php";
?>